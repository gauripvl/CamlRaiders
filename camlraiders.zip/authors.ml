
let hours_worked = [42; 42; 42]
