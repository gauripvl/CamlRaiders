
type sprite = {
  img: string;
  speed: int;
  mutable x: int;
  mutable y: int;
}